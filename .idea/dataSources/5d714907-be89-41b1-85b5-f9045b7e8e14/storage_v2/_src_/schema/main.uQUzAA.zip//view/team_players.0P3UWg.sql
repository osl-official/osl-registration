CREATE VIEW team_players as
select * from TeamPlayers;

