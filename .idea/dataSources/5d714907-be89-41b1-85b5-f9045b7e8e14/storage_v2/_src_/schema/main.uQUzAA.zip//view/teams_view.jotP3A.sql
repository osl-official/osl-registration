CREATE VIEW teams_view as
select * from Teams;

